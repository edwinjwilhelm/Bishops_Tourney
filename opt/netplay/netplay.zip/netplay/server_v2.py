import asyncio
import json
from typing import Dict, Any, List, Optional
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request
import socket
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
import os
import datetime
from fastapi.middleware.cors import CORSMiddleware
from .engine_adapter_v2 import create_engine
from . import engine_adapter_v2 as _adapter
import subprocess
import random
import io
import ipaddress
try:
    import qrcode
    from PIL import Image
except Exception:
    qrcode = None
    Image = None

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, 'static')
app.mount('/static', StaticFiles(directory=STATIC_DIR), name='static')
# Expose original piece assets for the web client
WORKSPACE_ROOT = os.path.dirname(BASE_DIR)
ASSET_DIR = os.path.join(WORKSPACE_ROOT, 'pieces')
if os.path.isdir(ASSET_DIR):
    app.mount('/assets', StaticFiles(directory=ASSET_DIR), name='assets')
GAMES_DIR = os.path.join(WORKSPACE_ROOT, 'games')
os.makedirs(GAMES_DIR, exist_ok=True)
SETTINGS_PATH = os.path.join(BASE_DIR, 'server_settings.json')

# Serve engine_manifest.json from workspace root
ENGINE_MANIFEST = os.path.join(WORKSPACE_ROOT, 'engine_manifest.json')

# Color seats supported by the UI
COLOR_SEATS = ("WHITE", "GREY", "BLACK", "PINK")

# LAN-only access control (default True). Can be toggled via server_settings.json { "lan_only": true|false }.
LAN_ONLY = True
try:
    if os.path.isfile(SETTINGS_PATH):
        with open(SETTINGS_PATH, 'r', encoding='utf-8') as _f:
            _s = json.load(_f)
        if isinstance(_s, dict) and 'lan_only' in _s:
            LAN_ONLY = bool(_s.get('lan_only'))
except Exception:
    pass

def _ip_is_private_or_loopback(host: str) -> bool:
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback
    except Exception:
        # If host is a hostname, try resolving and checking first result
        try:
            ip = ipaddress.ip_address(socket.gethostbyname(host))
            return ip.is_private or ip.is_loopback
        except Exception:
            # On failure, be safe and deny
            return False

@app.middleware('http')
async def _lan_only_http_guard(request, call_next):
    if LAN_ONLY:
        try:
            client_host = request.client.host if request.client else None
        except Exception:
            client_host = None
        # Allow localhost if detection fails
        if client_host and not _ip_is_private_or_loopback(client_host):
            return JSONResponse({'ok': False, 'error': 'LAN-only mode: external access blocked'}, status_code=403)
    return await call_next(request)

# Friendly alias and tolerant handler for host link page
@app.get('/host')
def host_alias():
    """Serve the Host Links page at a simple path."""
    path = os.path.join(STATIC_DIR, 'host_link.html')
    if os.path.exists(path):
        return FileResponse(path)
    return HTMLResponse('<h3>host_link.html not found</h3>', status_code=404)

@app.get('/static/host_link.html/{rest:path}')
def host_link_catchall(rest: str = ''):
    """Serve host_link.html even if extra path segments were appended (tolerant)."""
    path = os.path.join(STATIC_DIR, 'host_link.html')
    if os.path.exists(path):
        return FileResponse(path)
    return HTMLResponse('<h3>host_link.html not found</h3>', status_code=404)

@app.get('/engine_manifest.json')
def engine_manifest():
    if os.path.exists(ENGINE_MANIFEST):
        return FileResponse(ENGINE_MANIFEST, media_type='application/json')
    # Fallback minimal manifest
    return HTMLResponse('{"version":"unknown"}', media_type='application/json')

def _lan_ip_guess() -> Optional[str]:
    # Prefer local interface enumeration to avoid external reachability
    try:
        hostname = socket.gethostname()
        # getaddrinfo returns multiple addresses; choose first IPv4 non-loopback
        infos = socket.getaddrinfo(hostname, None, family=socket.AF_INET)
        for fam, st, proto, canon, sockaddr in infos:
            ip = sockaddr[0]
            if ip and not ip.startswith('127.'):
                return ip
    except Exception:
        pass
    # Fallback: classic UDP connect trick (still offline; no data sent)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
        s.close()
        if ip and not ip.startswith('127.'):
            return ip
    except Exception:
        pass
    try:
        hostname = socket.gethostname()
        ip = socket.gethostbyname(hostname)
        if ip and not ip.startswith('127.'):
            return ip
    except Exception:
        pass
    return None

@app.get('/whereami')
def whereami(req: Request):
    """Return base URLs: host header and LAN IP when available, choosing a best default for QR links."""
    try:
        scheme = req.url.scheme or 'http'
        host_hdr = (req.headers.get('host') or '').strip()
        base_host = f"{scheme}://{host_hdr}" if host_hdr else None
        # Extract port: prefer parsed URL port, else from host header, else default 8000
        try:
            port = int(req.url.port or 0)
        except Exception:
            port = 0
        if not port and host_hdr and ':' in host_hdr:
            try:
                port = int(host_hdr.rsplit(':', 1)[1])
            except Exception:
                port = 0
        if not port:
            port = 8000
        lan_ip = _lan_ip_guess()
        base_lan = f"{scheme}://{lan_ip}:{port}" if lan_ip else None
        # Choose best: if host header is localhost/127, prefer LAN; else prefer host header
        def is_loopback(h: Optional[str]) -> bool:
            if not h:
                return True
            return 'localhost' in h.lower() or '127.0.0.1' in h or h.startswith('::1')
        chosen = base_lan if is_loopback(host_hdr) and base_lan else (base_host or base_lan or f"{scheme}://127.0.0.1:{port}")
        return JSONResponse({
            'ok': True,
            'base': chosen,
            'base_host': base_host,
            'base_lan': base_lan,
            'join_random': chosen + '/static/join_random.html',
            'join_chess': chosen + '/static/join_chess.html'
        })
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)
    """Run the exporter script to refresh engine_manifest.json.
    Note: For local/dev use. Consider securing this endpoint in production.
    """
    exporter = os.path.join(WORKSPACE_ROOT, 'tools', 'export_manifest.py')
    if not os.path.exists(exporter):
        return JSONResponse({'ok': False, 'error': 'export_manifest.py not found'}, status_code=404)
    try:
        # Use the same Python executable the server runs under
        subprocess.check_call([os.sys.executable, exporter], cwd=WORKSPACE_ROOT)
        return JSONResponse({'ok': True})
    except subprocess.CalledProcessError as e:
        return JSONResponse({'ok': False, 'error': f'Exporter failed: {e}'}, status_code=500)

@app.post('/admin/reload-engine')
async def reload_engine_and_reset():
    """Hot-reload the Golden engine module and reset the current game.
    Use when Bishops_Golden.py has been updated to bring the Netplay server in sync.
    """
    try:
        # Reload the engine module in the adapter
        if hasattr(_adapter, 'reload_engine') and callable(_adapter.reload_engine):
            _adapter.reload_engine()
        else:
            return JSONResponse({'ok': False, 'error': 'reload_engine not available'}, status_code=500)
        # Reset the game so the new engine is used
        res = await hub.reset_game()
        return JSONResponse({'ok': True, **res})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get('/debug/piece-count')
def debug_piece_count():
    try:
        b = hub.engine.board
        engine_mod = _adapter.engine
        total = 0
        by = {c.name: 0 for c in engine_mod.TURN_ORDER}
        for r in range(engine_mod.BOARD_SIZE):
            for c in range(engine_mod.BOARD_SIZE):
                p = b.get(r, c)
                if p is not None:
                    total += 1
                    try:
                        by[p.color.name] += 1
                    except Exception:
                        pass
        return JSONResponse({'ok': True, 'total': total, 'byColor': by})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get('/debug/assets-check')
def debug_assets_check():
    try:
        exists = os.path.isdir(ASSET_DIR)
        return JSONResponse({'ok': True, 'exists': exists, 'dir': ASSET_DIR, 'mounted': exists})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get('/debug/diagnose')
def debug_diagnose():
    try:
        engine = hub.engine
        act = None
        try:
            act = engine.active_color().name
        except Exception:
            act = None
        try:
            legal = len(engine.legal_moves_for_active())
        except Exception:
            legal = None
        try:
            mode = hub.modes.get(act or '', 'HUM') if act else None
        except Exception:
            mode = None
        try:
            forced = getattr(engine, 'forced_turn', None)
            forced = forced.name if forced is not None else None
        except Exception:
            forced = None
        try:
            two = bool(getattr(_adapter.engine.gs, 'two_stage_active', False))
            lock = bool(getattr(_adapter.engine.gs, 'chess_lock', False))
            thr = int(getattr(_adapter.engine.gs, 'auto_elim_threshold', 0) or 0)
        except Exception:
            two, lock, thr = None, None, None
        try:
            alive = [c.name for c in engine.alive_colors()]
        except Exception:
            alive = None
        try:
            mv_count = len(engine.moves_list)
        except Exception:
            mv_count = None
        try:
            ai_should = (mode == 'AI') if (mode is not None) else None
            ai_running = bool(hub._ai_running)
            ai_last = hub._ai_last_stop
        except Exception:
            ai_should, ai_running, ai_last = None, None, None
        return JSONResponse({'ok': True, 'active': act, 'mode': mode, 'legal': legal, 'forced': forced, 'two_stage': two, 'chess_lock': lock, 'auto_elim_threshold': thr, 'alive': alive, 'moves': mv_count, 'ai_should_run': ai_should, 'ai_running': ai_running, 'ai_last_stop': ai_last})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.post('/admin/sync-rules')
def sync_rules_from_golden():
    """Extract RULES_REFERENCE from Bishops_Golden.py and write to static rules file.
    Note: For local/dev use. Consider securing this endpoint in production.
    """
    # Try to read RULES_REFERENCE off the already-loaded engine module used by engine_adapter_v2
    engine_mod = getattr(_adapter, 'engine', None)
    if engine_mod is None:
        return JSONResponse({'ok': False, 'error': 'Engine module not loaded'}, status_code=500)
    rules = getattr(engine_mod, 'RULES_REFERENCE', None)
    if not isinstance(rules, str) or not rules.strip():
        return JSONResponse({'ok': False, 'error': 'RULES_REFERENCE not found in engine'}, status_code=404)
    # Normalize newlines and strip trailing whitespace
    text = rules.replace('\r\n', '\n').replace('\r', '\n').strip() + "\n"
    out_path = os.path.join(STATIC_DIR, 'rules_reference.txt')
    try:
        with open(out_path, 'w', encoding='utf-8') as f:
            f.write(text)
        return JSONResponse({'ok': True, 'bytes': len(text), 'path': '/static/rules_reference.txt'})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': f'Failed to write rules: {e}'}, status_code=500)

class GameHub:
    def __init__(self):
        self.clients: Dict[str, WebSocket] = {}
        # Single shared engine instance; one game per process for now
        self.engine = create_engine()
        self.state: Dict[str, Any] = self.engine.serialize_state()
        # Keep the very first board as the initial snapshot for timeline/replay
        try:
            self.initial_board: List[List[Any]] = self._deep_copy_board(self.state.get('board'))
        except Exception:
            self.initial_board = self.state.get('board') or []
        self.lock = asyncio.Lock()
        # Per-color player mode mapping: 'HUM' or 'AI'
        self.modes: Dict[str, str] = { 'WHITE':'HUM', 'GREY':'HUM', 'BLACK':'HUM', 'PINK':'HUM' }
        # Background AI runner task handle
        self._ai_task = None
        # AI move delay (seconds)
        self.ai_delay_seconds = 1.0
        # AI loop diagnostics
        self._ai_running: bool = False
        self._ai_last_stop: Optional[str] = None
        # Auto-elimination threshold (0=Off, 18, 30)
        self.auto_elim_threshold = 18
        # Seats that have handed off control to AI for the current game
        self.quit_locked: set[str] = set()
        # Active new-game request (requires explicit confirmation)
        self.reset_pending_by: Optional[str] = None
        # Allow multiple spectators by assigning unique keys
        self._spectator_counter = 0
        self.duel_epoch_seen: int = 0
        self.duel_seat_map: Dict[str, str] = {}
        self.duel_ready: bool = True
        self.duel_wait_ms: int = 0
        self._duel_wait_handle = None
        self._duel_ai_pending: bool = False
        self._suppress_duel_ai_schedule: bool = False
        # Load persisted settings
        try:
            if os.path.isfile(SETTINGS_PATH):
                with open(SETTINGS_PATH, 'r', encoding='utf-8') as f:
                    s = json.load(f)
                if isinstance(s, dict):
                    v = int(s.get('auto_elim_threshold', 18))
                    if v in (0, 18, 30):
                        self.auto_elim_threshold = v
        except Exception:
            pass
        # Ensure engine.gs is aware of default modes if present
        try:
            for name, mode in self.modes.items():
                col = getattr(_adapter.engine.PColor, name)
                _adapter.engine.gs.player_is_ai[col] = (mode == 'AI')
            # Reflect auto-elim threshold to engine module
            setattr(_adapter.engine.gs, 'auto_elim_threshold', int(self.auto_elim_threshold))
        except Exception:
            pass

    def _deep_copy_board(self, board_grid):
        if not isinstance(board_grid, list):
            return []
        out = []
        for row in board_grid:
            r = []
            for cell in row or []:
                if cell is None:
                    r.append(None)
                else:
                    r.append({"kind": cell.get("kind"), "color": cell.get("color")})
            out.append(r)
        return out

    def _cancel_duel_ready_check(self) -> None:
        handle = getattr(self, '_duel_wait_handle', None)
        if handle is not None:
            try:
                handle.cancel()
            except Exception:
                pass
        self._duel_wait_handle = None

    def _schedule_duel_ready_check(self, wait_ms: int) -> None:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        delay = max(0.1, (wait_ms / 1000.0) if wait_ms else 0.3)
        self._cancel_duel_ready_check()
        self._duel_wait_handle = loop.call_later(delay, lambda: asyncio.create_task(self._ensure_ai_tick()))

    def _state_for_send(self) -> Dict[str, Any]:
        payload = self.engine.serialize_state()
        try:
            payload['initial'] = self._deep_copy_board(self.initial_board)
        except Exception:
            payload['initial'] = self.initial_board
        try:
            payload['modes'] = dict(self.modes)
        except Exception:
            payload['modes'] = { 'WHITE':'HUM', 'GREY':'HUM', 'BLACK':'HUM', 'PINK':'HUM' }
        try:
            payload['ai_delay_seconds'] = float(self.ai_delay_seconds)
        except Exception:
            payload['ai_delay_seconds'] = 1.0
        try:
            payload['auto_elim_threshold'] = int(self.auto_elim_threshold)
        except Exception:
            payload['auto_elim_threshold'] = 0
        try:
            payload['quit_locked'] = list(self.quit_locked)
        except Exception:
            payload['quit_locked'] = []
        payload['reset_pending_by'] = self.reset_pending_by
        duel_info = payload.get('duel')
        if isinstance(duel_info, dict) and self._align_duel_modes(duel_info):
            payload['modes'] = dict(self.modes)
            payload['quit_locked'] = list(self.quit_locked)
        if self._duel_ai_pending and not self._suppress_duel_ai_schedule:
            try:
                loop = asyncio.get_running_loop()
                loop.call_soon(lambda: asyncio.create_task(self._ensure_ai_tick()))
            except RuntimeError:
                pass
            self._duel_ai_pending = False
        return payload

    def _align_duel_modes(self, duel_info: Dict[str, Any]) -> bool:
        """Align hub state to the duel seat mapping. Returns True when modes/locks or readiness change."""
        try:
            active = bool(duel_info.get('active'))
        except Exception:
            active = False
        try:
            epoch = int(duel_info.get('epoch') or 0)
        except Exception:
            epoch = 0
        try:
            wait_ms = int(duel_info.get('wait_ms', 0) or 0)
        except Exception:
            wait_ms = 0
        ready = bool(duel_info.get('ready', True))
        prev_ready = self.duel_ready
        self.duel_wait_ms = max(0, wait_ms)
        changed_ready = False
        if not active:
            self.duel_seat_map = {}
            if epoch == 0:
                self.duel_epoch_seen = 0
            if not self.duel_ready or self.duel_wait_ms:
                changed_ready = True
            self.duel_ready = True
            self.duel_wait_ms = 0
            self._cancel_duel_ready_check()
            self._duel_ai_pending = False
            return changed_ready
        white_origin = 'WHITE'
        black_origin = 'BLACK'
        self.duel_seat_map = {'WHITE': 'WHITE', 'BLACK': 'BLACK'}
        changed = False
        finalists = {white_origin, black_origin}
        # Force finalists into human mode
        white_mode = 'HUM'
        black_mode = 'HUM'
        if self.modes.get('WHITE') != white_mode:
            self.modes['WHITE'] = white_mode
            changed = True
        if self.modes.get('BLACK') != black_mode:
            self.modes['BLACK'] = black_mode
            changed = True
        if self.modes.get(white_origin) != white_mode:
            self.modes[white_origin] = white_mode
            changed = True
        if self.modes.get(black_origin) != black_mode:
            self.modes[black_origin] = black_mode
            changed = True
        eliminated = [seat for seat in COLOR_SEATS if seat not in finalists]
        for seat in eliminated:
            if self.modes.get(seat) != 'AI':
                self.modes[seat] = 'AI'
                changed = True
            if seat not in self.quit_locked:
                self.quit_locked.add(seat)
                changed = True
        origin_white_locked = white_origin in self.quit_locked
        origin_black_locked = black_origin in self.quit_locked
        if origin_white_locked and 'WHITE' not in self.quit_locked:
            self.quit_locked.add('WHITE')
            changed = True
        if not origin_white_locked and 'WHITE' in self.quit_locked and white_origin != 'WHITE':
            self.quit_locked.discard('WHITE')
            changed = True
        if origin_black_locked and 'BLACK' not in self.quit_locked:
            self.quit_locked.add('BLACK')
            changed = True
        if not origin_black_locked and 'BLACK' in self.quit_locked and black_origin != 'BLACK':
            self.quit_locked.discard('BLACK')
            changed = True
        try:
            enum = _adapter.engine.PColor
            if enum:
                _adapter.engine.gs.player_is_ai[getattr(enum, 'WHITE')] = (self.modes.get('WHITE', 'HUM') == 'AI')
                _adapter.engine.gs.player_is_ai[getattr(enum, 'BLACK')] = (self.modes.get('BLACK', 'HUM') == 'AI')
                for seat in eliminated:
                    if hasattr(enum, seat):
                        _adapter.engine.gs.player_is_ai[getattr(enum, seat)] = True
        except Exception:
            pass
        if epoch and epoch != self.duel_epoch_seen:
            self.duel_epoch_seen = epoch
        if not ready:
            self.duel_ready = False
            if prev_ready:
                changed_ready = True
            self._schedule_duel_ready_check(self.duel_wait_ms)
            self._duel_ai_pending = False
        else:
            self.duel_ready = True
            if not prev_ready:
                changed_ready = True
                self._duel_ai_pending = True
            self._cancel_duel_ready_check()
        return changed or changed_ready

    def _canonical_seat(self, seat: str) -> str:
        try:
            key = (seat or 'SPECTATOR').upper()
        except Exception:
            key = 'SPECTATOR'
        return self.duel_seat_map.get(key, key)

    def _save_current_game(self) -> Dict[str, Any]:
        """Persist current game to games/ as a JSON file if any moves were played."""
        try:
            moves = list(self.engine.moves_list)
            if not moves:
                return {"ok": True, "saved": False}
            ended_at = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
            name = f"game_{ended_at}.json"
            body = {
                "started_at": getattr(self, 'started_at', None),
                "ended_at": ended_at,
                "initial": self.initial_board,
                "final": self.engine.serialize_state(),
                "moves": moves,
                "engine_version": getattr(_adapter.engine, 'VERSION_STR', 'unknown'),
            }
            with open(os.path.join(GAMES_DIR, name), 'w', encoding='utf-8') as f:
                json.dump(body, f, ensure_ascii=False)
            return {"ok": True, "saved": True, "file": name}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def connect(self, seat: str, ws: WebSocket):
        await ws.accept()
        async with self.lock:
            # Enforce one active connection per color seat (allow one spectator)
            try:
                s = (seat or "SPECTATOR").upper()
            except Exception:
                s = "SPECTATOR"
            if s in COLOR_SEATS and s in self.clients and self.clients.get(s) is not ws:
                # Seat already taken: inform and close
                try:
                    await ws.send_text(json.dumps({"type": "seat_denied", "seat": s, "reason": "taken"}))
                except Exception:
                    pass
                try:
                    await ws.close()
                except Exception:
                    pass
                return
            # For spectators, assign unique key so multiple viewers can connect simultaneously
            key = s
            if s not in COLOR_SEATS:
                self._spectator_counter += 1
                key = f"SPECTATOR#{self._spectator_counter}"
            self.clients[key] = ws
            await self._send_state(ws)

    async def disconnect(self, ws: WebSocket):
        async with self.lock:
            # Remove any mapping(s) that point to this WebSocket
            try:
                dead_keys = [k for k, v in self.clients.items() if v is ws]
                for k in dead_keys:
                    self.clients.pop(k, None)
            except Exception:
                # Fallback: clear any None entries
                for k, v in list(self.clients.items()):
                    if v is None:
                        self.clients.pop(k, None)

    async def _broadcast(self, message: Dict[str, Any]):
        dead = []
        for seat, ws in self.clients.items():
            try:
                await ws.send_text(json.dumps(message))
            except Exception:
                dead.append(seat)
        for d in dead:
            self.clients.pop(d, None)

    async def _send_state(self, ws: WebSocket):
        # Refresh from engine before sending
        self.state = self.engine.serialize_state()
        await ws.send_text(json.dumps({"type":"state","payload": self._state_for_send()}))

    async def reset_game(self) -> Dict[str, Any]:
        # Reinitialize engine and broadcast fresh state
        async with self.lock:
            # Save previous game if any moves were made
            try:
                self._save_current_game()
            except Exception:
                pass
            self.engine = create_engine()
            # Unlock any seats that quit-to-AI during the prior game
            for col in list(self.quit_locked):
                self.modes[col] = 'HUM'
            self.quit_locked.clear()
            self.reset_pending_by = None
            self.duel_epoch_seen = 0
            self.duel_seat_map = {}
            self.duel_seat_map = {}
            self.duel_ready = True
            self.duel_wait_ms = 0
            self._cancel_duel_ready_check()
            self._duel_ai_pending = False
            self.state = self.engine.serialize_state()
            try:
                self.initial_board = self._deep_copy_board(self.state.get('board'))
                self.started_at = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
            except Exception:
                self.initial_board = self.state.get('board')
            # Reapply player modes into fresh engine.gs
            try:
                for name, mode in self.modes.items():
                    col = getattr(_adapter.engine.PColor, name)
                    _adapter.engine.gs.player_is_ai[col] = (mode == 'AI')
                # Also reapply auto-elim threshold
                setattr(_adapter.engine.gs, 'auto_elim_threshold', int(self.auto_elim_threshold))
            except Exception:
                pass
            # Reset AI task and keep modes as-is
            if self._ai_task and not self._ai_task.done():
                try:
                    self._ai_task.cancel()
                except Exception:
                    pass
                self._ai_task = None
        await self._broadcast({"type": "state", "payload": self._state_for_send()})
        # Kick AI if needed on fresh board
        await self._ensure_ai_tick()
        return {"ok": True}

    async def reset_game_chess(self) -> Dict[str, Any]:
        """Reset to a chess-only session (WHITE vs BLACK inside 8×8)."""
        async with self.lock:
            try:
                self._save_current_game()
            except Exception:
                pass
            self.engine = create_engine()
            for col in list(self.quit_locked):
                self.modes[col] = 'HUM'
            self.quit_locked.clear()
            self.reset_pending_by = None
            self.duel_epoch_seen = 0
            try:
                # Switch engine board to chess-only and align flags
                if hasattr(self.engine, 'reset_chess_only'):
                    self.engine.reset_chess_only()
            except Exception:
                pass
            self.duel_ready = True
            self.duel_wait_ms = 0
            self._cancel_duel_ready_check()
            self._duel_ai_pending = False
            self.state = self.engine.serialize_state()
            try:
                self.initial_board = self._deep_copy_board(self.state.get('board'))
                self.started_at = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
            except Exception:
                self.initial_board = self.state.get('board')
            # Reapply player modes to engine.gs (only WHITE/BLACK relevant)
            try:
                for name, mode in self.modes.items():
                    col = getattr(_adapter.engine.PColor, name)
                    _adapter.engine.gs.player_is_ai[col] = (mode == 'AI')
                setattr(_adapter.engine.gs, 'auto_elim_threshold', int(self.auto_elim_threshold))
            except Exception:
                pass
            # Cancel any running AI loop
            if self._ai_task and not self._ai_task.done():
                try:
                    self._ai_task.cancel()
                except Exception:
                    pass
                self._ai_task = None
        await self._broadcast({"type": "state", "payload": self._state_for_send()})
        await self._ensure_ai_tick()
        return {"ok": True}

    async def _ensure_ai_tick(self):
        """Start or continue an AI loop if the active seat is AI. Idempotent."""
        # If a task is already running, let it continue
        if self._ai_task and not self._ai_task.done():
            return
        payload = None
        async with self.lock:
            try:
                self.state = self.engine.serialize_state()
            except Exception:
                self.state = {}
            self._suppress_duel_ai_schedule = True
            try:
                payload = self._state_for_send()
            finally:
                self._suppress_duel_ai_schedule = False
            # If we just cleared AI pending inside the suppression window, note it
            pending_ai = self._duel_ai_pending
            self._duel_ai_pending = False
        if payload:
            await self._broadcast({"type":"state","payload": payload})
        else:
            pending_ai = False
        if not self.duel_ready:
            if self._duel_wait_handle is None:
                self._schedule_duel_ready_check(self.duel_wait_ms)
            return
        if pending_ai and (self._ai_task and not self._ai_task.done()):
            return

        async def _runner():
            try:
                self._ai_running = True
                self._ai_last_stop = None
                while True:
                    async with self.lock:
                        try:
                            active = self.engine.active_color().name
                        except Exception:
                            active = None
                        mode = self.modes.get(active or '', 'HUM') if active else 'HUM'
                    if active is None or mode != 'AI':
                        self._ai_last_stop = 'inactive-or-human'
                        break
                    # Small think delay for UX (configurable)
                    delay = self.ai_delay_seconds
                    try:
                        if not isinstance(delay, (int,float)) or delay < 0: delay = 1.0
                    except Exception:
                        delay = 1.0
                    await asyncio.sleep(delay)
                    # Choose and apply AI move
                    try:
                        color_enum = getattr(_adapter.engine.PColor, active)
                        mustf = getattr(_adapter.engine, 'must_enter_filter_for', None)
                        gracef = getattr(_adapter.engine, 'grace_blocks_check_for', None)
                        two_stage = bool(getattr(_adapter.engine.gs, 'two_stage_active', False))
                        must_filter = mustf(self.engine.board, color_enum) if callable(mustf) else None
                        grace_block = (lambda m, opp: False)
                        if callable(gracef):
                            try:
                                grace_block = gracef(color_enum)
                            except Exception:
                                grace_block = (lambda m, opp: False)
                        chooser = getattr(_adapter.engine, 'choose_ai_move', None)
                        move = None
                        if callable(chooser):
                            move = chooser(self.engine.board, color_enum, two_stage, must_filter, grace_block, None)
                        # If chooser didn't return a move, fall back to any legal move (already filtered by engine adapter)
                        if not move:
                            legal = self.engine.legal_moves_for_active()
                            if legal:
                                # Choose a deterministic-but-varied fallback: middle move, else first
                                try:
                                    idx = max(0, min(len(legal)-1, len(legal)//2))
                                    move = legal[idx]
                                except Exception:
                                    move = legal[0]
                        if not move:
                            self._ai_last_stop = 'no-move'
                            break
                        if len(move) == 4:
                            sr, sc, er, ec = map(int, move)
                        else:
                            sr = int(move[0]); sc = int(move[1]); er = int(move[2]); ec = int(move[3])
                        # Apply via engine wrapper
                        res = self.engine.apply_move(active, sr, sc, er, ec)
                        if not res.get('ok'):
                            # Illegal or failed; stop AI loop to avoid spin
                            self._ai_last_stop = f"apply-failed:{res.get('error')}"
                            break
                        # Broadcast new state after AI move
                        await self._broadcast({"type":"state","payload": self._state_for_send()})
                    except Exception as e:
                        self._ai_last_stop = f"exception:{e}"
                        break
                # End loop
                return
            finally:
                self._ai_running = False
                self._ai_task = None
        # Only start if it's AI's turn now
        try:
            act = self.engine.active_color().name
            if self.modes.get(act, 'HUM') == 'AI':
                self._ai_task = asyncio.create_task(_runner())
        except Exception:
            pass

    async def handle(self, seat: str, msg: Dict[str, Any], ws: WebSocket):
        t = msg.get("type")
        try:
            seat_raw = (seat or "SPECTATOR").upper()
        except Exception:
            seat_raw = "SPECTATOR"
        seat_norm = self._canonical_seat(seat_raw)
        if t == "hello":
            # no-op
            return
        if t == "duel_ready":
            async with self.lock:
                try:
                    mark = getattr(self.engine, 'mark_duel_ready', None)
                    if callable(mark):
                        mark()
                except Exception:
                    pass
                self.state = self.engine.serialize_state()
                payload = self._state_for_send()
            await self._broadcast({"type":"state","payload": payload})
            await self._ensure_ai_tick()
            return
        if t == "force_duel":
            if seat_norm not in COLOR_SEATS:
                await ws.send_text(json.dumps({"type": "error", "payload": "Force Duel requires an active seat."}))
                return
            err_msg = None
            async with self.lock:
                try:
                    ok = bool(getattr(self.engine, 'force_duel', lambda: False)())
                except Exception as exc:  # pragma: no cover - defensive
                    ok = False
                    err_msg = f"Force duel failed: {exc}"
                if ok:
                    try:
                        setattr(self.engine, 'forced_turn', None)
                    except Exception:
                        pass
                    try:
                        if hasattr(self.engine, 'turn_i'):
                            self.engine.turn_i = _adapter.engine.TURN_ORDER.index(_adapter.engine.PColor.WHITE)
                    except Exception:
                        pass
                    self.state = self.engine.serialize_state()
            if not ok:
                await ws.send_text(json.dumps({"type": "error", "payload": err_msg or "Force duel failed."}))
            else:
                await self._broadcast({"type":"state","payload": self._state_for_send()})
                await self._ensure_ai_tick()
            return
        if t == "set_ai_delay":
            p = msg.get('payload') or {}
            try:
                sec = float(p.get('seconds', 1.0))
                if sec < 0: sec = 0.0
                if sec > 10: sec = 10.0
                self.ai_delay_seconds = sec
            except Exception:
                self.ai_delay_seconds = 1.0
            await self._broadcast({"type":"state","payload": self._state_for_send()})
            return
        if t == "request_new_game":
            if seat_norm not in COLOR_SEATS:
                await ws.send_text(json.dumps({"type":"error","payload":"Only seated players can request a new game."}))
                return
            conflict: Optional[str] = None
            async with self.lock:
                if self.reset_pending_by is None:
                    self.reset_pending_by = seat_norm
                elif self.reset_pending_by == seat_norm:
                    # Toggle off (cancel) if the same seat taps again
                    self.reset_pending_by = None
                else:
                    conflict = self.reset_pending_by
            await self._broadcast({"type":"state","payload": self._state_for_send()})
            if conflict:
                await ws.send_text(json.dumps({"type":"error","payload": f"New game already requested by {conflict}."}))
            return
        if t == "confirm_new_game":
            if seat_norm not in COLOR_SEATS:
                await ws.send_text(json.dumps({"type":"error","payload":"Only seated players can confirm a new game."}))
                return
            confirmed = False
            blocker: Optional[str] = None
            async with self.lock:
                if self.reset_pending_by == seat_norm:
                    self.reset_pending_by = None
                    confirmed = True
                else:
                    blocker = self.reset_pending_by
                new_state = self._state_for_send()
            await self._broadcast({"type":"state","payload": new_state})
            if not confirmed:
                if blocker:
                    await ws.send_text(json.dumps({"type":"error","payload": f"Awaiting confirmation from {blocker}."}))
                else:
                    await ws.send_text(json.dumps({"type":"error","payload":"No new game request to confirm."}))
                return
            await self.reset_game()
            return
        if t == "set_auto_elim":
            # payload: { threshold: 0|18|30 }
            p = msg.get('payload') or {}
            try:
                thr = int(p.get('threshold', 18))
            except Exception:
                thr = 18
            if thr not in (0, 18, 30):
                # Clamp to nearest allowed
                thr = 0 if thr <= 9 else (18 if thr <= 24 else 30)
            async with self.lock:
                self.auto_elim_threshold = thr
                try:
                    setattr(_adapter.engine.gs, 'auto_elim_threshold', int(thr))
                except Exception:
                    pass
                # Persist settings
                try:
                    with open(SETTINGS_PATH, 'w', encoding='utf-8') as f:
                        json.dump({'auto_elim_threshold': int(self.auto_elim_threshold)}, f)
                except Exception:
                    pass
            await self._broadcast({"type":"state","payload": self._state_for_send()})
            # If an AI should move next, ensure loop runs
            await self._ensure_ai_tick()
            return
        if t == "set_mode":
            # payload: { color: 'WHITE'|'GREY'|'BLACK'|'PINK', mode: 'HUM'|'AI' }
            p = msg.get('payload') or {}
            col_raw = str(p.get('color', '')).upper()
            col = self._canonical_seat(col_raw)
            mode = 'AI' if str(p.get('mode','')).upper() == 'AI' else 'HUM'
            if col in ('WHITE','GREY','BLACK','PINK'):
                denied = False
                async with self.lock:
                    locked = (col in self.quit_locked) or (col_raw in self.quit_locked)
                    if locked and mode != 'AI':
                        denied = True
                    else:
                        targets = {col}
                        if col_raw in ('WHITE','GREY','BLACK','PINK'):
                            targets.add(col_raw)
                        for name in targets:
                            self.modes[name] = mode
                        try:
                            enum = _adapter.engine.PColor
                            if enum:
                                if hasattr(enum, col):
                                    _adapter.engine.gs.player_is_ai[getattr(enum, col)] = (mode == 'AI')
                                if col_raw != col and hasattr(enum, col_raw):
                                    _adapter.engine.gs.player_is_ai[getattr(enum, col_raw)] = (mode == 'AI')
                        except Exception:
                            pass
                    new_state = self._state_for_send()
                await self._broadcast({"type":"state","payload": new_state})
                if denied:
                    await ws.send_text(json.dumps({"type":"error","payload": "Seat is locked to AI for the remainder of this game."}))
                else:
                    # Kick AI if it's now an AI turn
                    await self._ensure_ai_tick()
            return
        if t == "quit_seat":
            if seat_norm not in COLOR_SEATS:
                await ws.send_text(json.dumps({"type": "error", "payload": "You must occupy a seat to quit to AI."}))
                return
            async with self.lock:
                self.quit_locked.add(seat_norm)
                if seat_raw in COLOR_SEATS:
                    self.quit_locked.add(seat_raw)
                for name in {seat_norm, seat_raw}:
                    if name in COLOR_SEATS:
                        self.modes[name] = 'AI'
                try:
                    enum = _adapter.engine.PColor
                    if enum:
                        if hasattr(enum, seat_norm):
                            _adapter.engine.gs.player_is_ai[getattr(enum, seat_norm)] = True
                        if seat_raw != seat_norm and hasattr(enum, seat_raw):
                            _adapter.engine.gs.player_is_ai[getattr(enum, seat_raw)] = True
                except Exception:
                    pass
                new_state = self._state_for_send()
            await self._broadcast({"type":"state","payload": new_state})
            await self._ensure_ai_tick()
            return
        if t == "move":
            # Expect payload: {sr,sc,er,ec}
            mv = msg.get("payload", {})
            try:
                sr, sc, er, ec = int(mv.get("sr")), int(mv.get("sc")), int(mv.get("er")), int(mv.get("ec"))
            except Exception:
                await self._broadcast({"type":"error","payload": "Invalid move payload"})
                return
            if seat_norm in self.quit_locked or seat_raw in self.quit_locked:
                await ws.send_text(json.dumps({"type":"error","payload":"Seat is locked to AI for this game."}))
                return
            async with self.lock:
                if not self.duel_ready:
                    try:
                        mark = getattr(self.engine, 'mark_duel_ready', None)
                        if callable(mark):
                            mark()
                    except Exception:
                        pass
                result = self.engine.apply_move(seat_norm, sr, sc, er, ec)
                if result.get("ok"):
                    self.state = self.engine.serialize_state()
                    payload = self._state_for_send()
                else:
                    payload = None
            if not result.get("ok"):
                await self._broadcast({"type":"error","payload": result.get("error", "Illegal move")})
                return
            await self._broadcast({"type":"state","payload": payload})
            # After a human move, if next to play is AI, start AI loop
            await self._ensure_ai_tick()
        elif t == "legal_for":
            # Expect payload: {sr, sc} and return legal destinations for active color matching that source
            try:
                sr, sc = int(msg.get("payload", {}).get("sr")), int(msg.get("payload", {}).get("sc"))
            except Exception:
                await ws.send_text(json.dumps({"type":"error","payload":"Invalid legal_for payload"}))
                return
            moves = []
            try:
                for (r0, c0, r1, c1) in self.engine.legal_moves_for_active():
                    if r0 == sr and c0 == sc:
                        moves.append({"er": int(r1), "ec": int(c1)})
            except Exception:
                pass
            await ws.send_text(json.dumps({"type":"legal","payload": {"sr": sr, "sc": sc, "moves": moves}}))
        elif t == "request_state":
            # Send current state to all (or could send only to requester if we tracked it)
            self.state = self.engine.serialize_state()
            await self._broadcast({"type":"state","payload": self._state_for_send()})
            await self._ensure_ai_tick()

hub = GameHub()

@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    seat = ws.query_params.get("seat", "SPECTATOR").upper()
    await hub.connect(seat, ws)
    try:
        while True:
            txt = await ws.receive_text()
            try:
                msg = json.loads(txt)
            except Exception:
                msg = {"type":"raw","payload": txt}
            try:
                await hub.handle(seat, msg, ws)
            except Exception as e:
                # Never crash the socket loop on handler errors; report to client
                try:
                    await ws.send_text(json.dumps({"type": "error", "payload": f"server error: {e}"}))
                except Exception:
                    pass
    except WebSocketDisconnect:
        await hub.disconnect(ws)

@app.get('/seats')
def seats_status():
    """Report which color seats are taken/available (best-effort; race-safe claims still enforced on connect)."""
    try:
        taken = [s for s in hub.clients.keys() if s in COLOR_SEATS]
        avail = [s for s in COLOR_SEATS if s not in taken]
        # Shuffle available for caller-side random pick variety
        rnd = list(avail)
        random.shuffle(rnd)
        return JSONResponse({'ok': True, 'taken': taken, 'available': avail, 'available_shuffled': rnd})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get("/")
def index():
    index_path = os.path.join(STATIC_DIR, 'index.html')
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return HTMLResponse("<h1>Netplay server running</h1><p>No index.html found.</p>")

@app.get('/qr.png')
def qr_png(url: str):
    """Return a QR code PNG for the given URL. Fully offline (no CDN)."""
    if not url or len(url) > 512:
        return JSONResponse({'ok': False, 'error': 'invalid url'}, status_code=400)
    if qrcode is None:
        return JSONResponse({'ok': False, 'error': 'qrcode lib not installed'}, status_code=500)
    try:
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=8, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        bio = io.BytesIO()
        img.save(bio, format='PNG')
        bio.seek(0)
        return HTMLResponse(bio.getvalue(), media_type='image/png')
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.post('/admin/new-game')
async def new_game():
    try:
        res = await hub.reset_game()
        return JSONResponse({"ok": True, **res})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

@app.post('/admin/new-chess')
async def new_chess():
    try:
        res = await hub.reset_game_chess()
        return JSONResponse({"ok": True, **res})
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

@app.post('/admin/save-now')
def save_now():
    """Persist the current game to the games/ folder without resetting.
    Returns { ok, saved, file? }.
    """
    try:
        res = hub._save_current_game()
        return JSONResponse(res)
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get('/library/list')
def library_list():
    try:
        items = []
        for fn in sorted(os.listdir(GAMES_DIR)):
            if not fn.lower().endswith('.json'): continue
            fp = os.path.join(GAMES_DIR, fn)
            try:
                with open(fp, 'r', encoding='utf-8') as f:
                    j = json.load(f)
                items.append({
                    'name': fn,
                    'ended_at': j.get('ended_at'),
                    'moves': len(j.get('moves', [])),
                })
            except Exception:
                items.append({'name': fn, 'ended_at': None, 'moves': None})
        return JSONResponse({'ok': True, 'items': items})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get('/library/game/{name}')
def library_game(name: str):
    try:
        safe = os.path.basename(name)
        path = os.path.join(GAMES_DIR, safe)
        if not os.path.exists(path):
            return JSONResponse({'ok': False, 'error': 'not found'}, status_code=404)
        return FileResponse(path, media_type='application/json', filename=safe)
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)

@app.get('/debug/legal')
def debug_legal(limit: Optional[int] = 10):
    try:
        lim = int(limit or 10)
        if lim < 1:
            lim = 1
        if lim > 200:
            lim = 200
        out = []
        for i, (sr, sc, er, ec) in enumerate(hub.engine.legal_moves_for_active()):
            if i >= lim:
                break
            out.append({'sr': int(sr), 'sc': int(sc), 'er': int(er), 'ec': int(ec)})
        return JSONResponse({'ok': True, 'count': len(out), 'moves': out})
    except Exception as e:
        return JSONResponse({'ok': False, 'error': str(e)}, status_code=500)
