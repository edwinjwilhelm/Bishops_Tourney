# Bishops Netplay (Prototype)

This is a minimal networked prototype to let up to 4 people connect to a single game host from their browsers.

What it is:
- A FastAPI WebSocket server hosting a single shared game channel
- A static web client (index.html) that connects as WHITE/GREY/BLACK/PINK (or spectator) and receives broadcasts
- Headless engine bridge — server validates and applies moves using the pygame engine (no window)

## Quick start (Windows PowerShell)

1. Create a virtual environment (optional but recommended)

```
python -m venv .venv
. .venv\Scripts\Activate.ps1
```

2. Install dependencies

```
pip install -r netplay/requirements.txt
```

3. Run the server

```
python -m uvicorn netplay.server:app --reload --host 0.0.0.0 --port 8000
```

4. Open the client in your browser(s)

- Navigate to http://localhost:8000
- Pick a seat (WHITE/GREY/BLACK/PINK) and click Connect
- Open multiple tabs (or different browsers) to simulate multiple humans

## Minimal protocol

- Connect: WebSocket to ws://localhost:8000/ws?seat=WHITE (or GREY/BLACK/PINK/SPECTATOR)
- Server messages:
	- { "type":"state", "payload": { turn, board[14][14], alive[], moves[] } }
	- { "type":"error", "payload": "string message" }
- Client → Server:
	- { "type":"move", "payload": { "sr":int, "sc":int, "er":int, "ec":int } }  (must be the active seat)

Tip: You can try a move from the browser console after connecting:

```
ws.send(JSON.stringify({type:'move', payload:{sr:12, sc:1, er:11, ec:1}}))
```

Coordinates use the engine's 14×14 board indices (0..13).

## Next steps (planned)

- Bridge the engine: validate moves, maintain authoritative board/state, and broadcast updates
- Per-seat rotation and board rendering in the web client (active seat at bottom)
- Drag/click move input, highlights, and notation
- Multi-game support (room IDs)
- Persistence & reconnection
